CREATE DATABASE  IF NOT EXISTS `ecomapp` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `ecomapp`;
-- MySQL dump 10.13  Distrib 5.6.17, for Win32 (x86)
--
-- Host: 127.0.0.1    Database: ecomapp
-- ------------------------------------------------------
-- Server version	5.6.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `added_date` datetime DEFAULT NULL,
  `code` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `label` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` double DEFAULT NULL,
  `qte_stock` int(11) NOT NULL,
  `uuid` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `brand_id` bigint(20) DEFAULT NULL,
  `category_id` bigint(20) DEFAULT NULL,
  `owner_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKs6cydsualtsrprvlf2bb3lcam` (`brand_id`),
  KEY `FK1mtsbur82frn64de7balymq9s` (`category_id`),
  KEY `FKn3le0a5l0wmq4gs20rn3ty36x` (`owner_id`),
  CONSTRAINT `FK1mtsbur82frn64de7balymq9s` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`),
  CONSTRAINT `FKn3le0a5l0wmq4gs20rn3ty36x` FOREIGN KEY (`owner_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FKpbqubietdkvyj3kgbk3ognmge` FOREIGN KEY (`owner_id`) REFERENCES `user_table` (`id`),
  CONSTRAINT `FKs6cydsualtsrprvlf2bb3lcam` FOREIGN KEY (`brand_id`) REFERENCES `brand` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES ('02ff434a-8c4d-4f80-b4da-ec4269297f21','2020-01-17 12:15:04','001','Milk powder','Groceries',10,6,'364753ed-d42c-bf97-d5ec-c0e5d263ae18',3,1,NULL),('039548e6-ff76-477e-81e5-530122bd4e6f','2020-01-17 12:32:51','002','Apple 11pro max','Mobiles',1323,123,'c24d9af0-e391-e41a-d547-b014f411821a',1,3,NULL),('1683b155-3d93-4778-8d89-2bd7def3b6ce','2020-01-17 12:33:11','003','MilkMan a Novel','Novels',7.99,54,'c5a3ee21-9fce-280f-0e93-9cf2eddb17c7',4,2,NULL),('32b6d465-fcd0-47d1-b870-adf46e583355','2020-01-17 12:49:46','123','BOSE Headphone','Headphone',120,50,'5e7a46b8-bc71-1c98-8879-ef28e69dcff4',2,3,NULL),('61e4b7b1-dc67-468f-aff8-3aa796f56863','2020-01-17 12:48:41','006','Rustic Wall Sconces Mason Jar Sconces Handmade Wall Art Hanging Design','Lights',50,122,'4026f564-7f44-4dff-31a8-f02f14162abf',5,4,NULL),('8845469e-a214-4dd5-b98d-646a8e6d60d9','2020-01-17 12:56:35','007','Samsung galaxy A10','Mobiles',400,35,'2e81f152-eb0a-e9bb-734f-c35f39a6cbf4',7,3,NULL),('bfaacf8a-9b6c-4030-bb1a-bddd1f6b7165','2020-01-17 12:59:47','008','Nestle, Toll House Cookie Dough Ice Cream, Pint (8 Count)','Cookies',43,80,'b91cacaa-eaee-682a-145b-f5f35d2b2468',3,1,NULL),('e2b3fb14-0d7a-4cf6-989f-bf8312165b19','2020-01-17 12:46:46','005','LIGHTSHARE 16Inch 36LED Cherry Blossom Bonsai Light,','Home Decor',25.99,51,'2877cc2b-4a0b-1145-a6a8-f74fd1b33756',6,4,NULL);
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-01-17 14:16:04


select * from role
-- delete from role;
--insert into role values (1, 'ADMIN', 'Administrator'), (2, 'USER', 'User')

package org.uppu.product.service.api;

import org.uppu.product.service.exception.NotFoundException;

public interface ICartProductService {

	void deleteCartProduct(Long id) throws NotFoundException;
	
}

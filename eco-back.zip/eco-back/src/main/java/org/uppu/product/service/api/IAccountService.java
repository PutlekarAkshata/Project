package org.uppu.product.service.api;

import java.util.List;

import org.uppu.product.domain.Account;
import org.uppu.product.service.exception.NotFoundException;

public interface IAccountService {

	Account addAccount(Account accountd);

	Account findAccount(long id) throws NotFoundException;

	List<Account> findAllAccounts();

	void deleteAccount(long id) throws NotFoundException;

	List<Account> searchAccounts(Account accountdtDto) throws NotFoundException;
	
	Account findAccountByUsername(String username) throws NotFoundException;
}

package org.uppu.product.service.api;

import java.util.List;

import org.uppu.product.domain.Brand;
import org.uppu.product.service.exception.NotFoundException;

public interface IBrandService {

	Brand addBrand(Brand brand);

	Brand findBrand(long id) throws NotFoundException;

	List<Brand> findAllBrands();

	void deleteBrand(long id) throws NotFoundException;

	List<Brand> searchBrands(Brand brandtDto) throws NotFoundException;

}

package org.uppu.product.service.api;

import java.util.List;

import org.uppu.product.domain.Cart;
import org.uppu.product.domain.dto.CartDto;
import org.uppu.product.service.exception.NotFoundException;

public interface ICartService {

	Cart addToCart(CartDto cart);
	
	Cart minusProductFromCart(CartDto cart) throws NotFoundException;

	Cart findCart(long id) throws NotFoundException;

	List<Cart> findAllCarts();

	void deleteCart(long id) throws NotFoundException;

	List<Cart> searchCarts(Cart cartDto) throws NotFoundException;

	Cart findByUserId(Long userId) throws NotFoundException;

	void deleteProductFromCart(String productId, String username);

	Cart findByUsername(String username) throws NotFoundException;

}

package org.uppu.product.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.uppu.product.domain.CartProduct;
import org.uppu.product.repository.CartProductRepository;
import org.uppu.product.service.api.ICartProductService;
import org.uppu.product.service.exception.NotFoundException;

@Service
public class CartProductService implements ICartProductService {

	@Autowired
	private CartProductRepository  cartProductRepo;

	@Override
	public void deleteCartProduct(Long id) throws NotFoundException {
 		if(!cartProductRepo.exists(id))
			throw new NotFoundException("NOT.FOUND", "Cart product not found");
 		CartProduct cp = cartProductRepo.findOne(id);
		cartProductRepo.delete(cp);
	}
	
}

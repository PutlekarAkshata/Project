package org.uppu.product.service.api;

import org.uppu.product.domain.Account;
import org.uppu.product.service.exception.BadCredentialsException;
import org.uppu.product.service.exception.NotFoundException;

public interface IAuthenticationService {

	Account authenticate(Account account) throws NotFoundException, BadCredentialsException;
}

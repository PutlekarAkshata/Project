package org.uppu.product.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.uppu.product.domain.Category;

public interface CategoryRepository extends JpaRepository<Category, Long> {
}

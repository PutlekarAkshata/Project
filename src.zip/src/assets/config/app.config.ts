// export const env = {
//     baseURL : "http://localhost:9095",
//     productRoute : "/product",
//     prefix: "/api/v1",
//     authenticationRoute: "/authentication"
// }